# == Schema Information
#
# Table name: menu_items
#
#  id         :integer          not null, primary key
#  page_id    :integer
#  menu_id    :integer
#  catalog_id :integer
#  weight     :integer
#  link       :string(255)
#  title      :string(255)
#  created_at :datetime
#  updated_at :datetime
#

class MenuItem < ActiveRecord::Base
  # before_update :update_item


  belongs_to :menu
  belongs_to :page
  belongs_to :catalog

  # def update_item
  #   if self.page_id
  #     @page = self.page
  #     self.title = @page.title
  #     self.link = page_url(@page)
  #   else
  #     self.title = self.catalog.title
  #     self.link = catalog_url(self.catalog)
  #   end
  # end

end
