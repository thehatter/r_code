# config/initializers/non_digest_assets.rb

NonStupidDigestAssets.whitelist = [/ckeditor\/.*/]