# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
RCode::Application.config.secret_key_base = '78fbf876b14799d0d29dcf102243f8a2261764069cadf24c45d2cc4d42c9ff462f9b6efe3a89b340ec32298e15d7b5d69c3c5ff25b9d81dc468eb4ab1f4d1a2b'
