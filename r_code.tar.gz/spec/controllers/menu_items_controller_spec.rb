require 'spec_helper'

describe MenuItemsController do

end
