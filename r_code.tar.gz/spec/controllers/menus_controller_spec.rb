require 'spec_helper'

describe MenusController do

end
