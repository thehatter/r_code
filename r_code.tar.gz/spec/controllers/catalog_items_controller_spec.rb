require 'spec_helper'

describe CatalogItemsController do

end
