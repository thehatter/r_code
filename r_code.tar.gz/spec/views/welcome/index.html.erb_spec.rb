require 'spec_helper'

describe "welcome/index.html.erb" do
  pending "add some examples to (or delete) #{__FILE__}"
end
